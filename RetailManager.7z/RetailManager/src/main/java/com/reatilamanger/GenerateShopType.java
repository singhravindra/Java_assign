package com.reatilamanger;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class GenerateShopType {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

	/*	shopNameFactory shopname = new shopNameFactory();
		System.out.print("Enter the name of the shop: ");
		
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));  

		String shoptype = br.readLine();
		
		// I will get the corresponding shop type object of that class
		shopname.getshopName(shoptype);
		*/
		

	}

}
