package com.reatilamanger;

public abstract class shopDetails {

	abstract void getShopName();

	protected String shopName;
	protected int shopNumber;
	protected int shopPostcode;
	
}


