package com.reatilamanger;

public class shopNameFactory {

		public CakeShop getshopName(String shoptype){
			
			// Determining Type of the shop and returning its object
			if(shoptype.equalsIgnoreCase("CakeShop")) {  
				return new CakeShop();  
            }

			// TODO for rest of the classes....
			
			
			
			return null;  
		
		}
}
