package com.reatilamanger;

public class CakeShop extends shopDetails {

	@Override
	public void getShopName() {
		// TODO Auto-generated method stub
		shopName = "CakeShop";
		shopNumber = 111;
		shopPostcode = 10101;
	}

	
	
}
