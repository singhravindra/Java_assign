package com.reatilamanger;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
	
@SpringBootApplication
public class RetailManagerApplication {

	public static void main(String[] args) throws IOException {
		
	//	SpringApplication.run(RetailManagerApplication.class, args);
		
		// Creating Factory object to return particular shop object
		shopNameFactory shopname = new shopNameFactory();
		System.out.print("Enter the name of the shop: ");
		
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));  

		String shoptype = br.readLine();
		
		// I will get the corresponding shop type object of that class
		shopDetails sd = shopname.getshopName(shoptype);
		
		SpringApplication.run(RetailManagerApplication.class, sd.toString());
	}
}


