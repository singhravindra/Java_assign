package com.reatilamanger;

import org.glassfish.jersey.server.ResourceConfig;
import org.springframework.context.annotation.Configuration;

import Resources.shopResources;

@Configuration
public class JerseyConfig extends ResourceConfig {

	public JerseyConfig() {

		register(shopResources.class);
	}

}