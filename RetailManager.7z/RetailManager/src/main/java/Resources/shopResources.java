package Resources;

import java.util.List;

import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.springframework.stereotype.Component;

import com.reatilamanger.*;
import com.reatilamanger.DTO.cordiantesDTO;
import com.reatilamanger.DTO.shopDetailsDTO;

import service.mappingServices;
import service.ShopResourceService;
import Util.ShopFinder;

@Component
@Path("/shop")
public class shopResources {


	@Inject
	private mappingServices mappingService;

	@Inject
	private ShopResourceService shopResourceServie;
	
	@Inject
	ShopFinder shopFinder;

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Response getJson() {

	/*	shopDetailsDTO shop = new shopDetailsDTO();
		shop.setName("sp infocity");
		shop.setAddress("hadapsar");
		shop.setPostalCode("412308"); */
		
		CakeShop cakeshop = new CakeShop();
		cakeshop.getShopName();

		return Response.status(200).entity(shop).build();
	}

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/save")
	public Response saveShop(Shop shop) {

		cordiantesDTO coordinates = null;

		try {

			final String locationAddress = shop.getName() + shop.getAddress() + shop.getPostalCode();

			coordinates = mappingService.getGeoCoordinates(locationAddress);

			if (coordinates != null) {

				shop.setLatitude(coordinates.getLatitude());
				shop.setLongitude(coordinates.getLongitude());

				shopResourceServie.save(shop);
			}

		} catch (Exception e) {

		}
		return Response.status(200).entity(shop).build();
	}

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/findNearestShop")
	public Response findNearestShop(cordiantesDTO coordinates) {
		
		Shop shop = shopFinder.getNearestShop(coordinates);

		return Response.status(200).entity(shop).build();

	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/shops")
	public Response getAllShops() {

		List<shopDetailsDTO> list = shopResourceServie.getAllShops();

		return Response.status(200).entity(list).build();

	}

}
