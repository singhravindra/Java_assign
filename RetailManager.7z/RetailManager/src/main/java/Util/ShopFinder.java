package Util;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Component;

import Repository.shopResourceRepository;
import com.reatilamanger.*;
import com.reatilamanger.DTO.cordiantesDTO;
import com.reatilamanger.DTO.shopDetailsDTO;

@Component
public class ShopFinder {

	@Inject
	private  shopResourceRepository shopResourceRepository;

	public  shopDetailsDTO getNearestShop(cordiantesDTO coordinates) {
		shopDetailsDTO shop = null;

		try {
			double distance = 0;
			double localdistance = 0;
			List<shopDetailsDTO> listOfShops = shopResourceRepository.getAllShops();

			if (!listOfShops.isEmpty()) {
				shop = listOfShops.get(0);
				distance = CoordintesDistance(coordinates, new cordiantesDTO(shop.getLatitude(), shop.getLongitude()));
			}
			localdistance = distance;
			final int length = listOfShops.size();
			int index = -1;
			for (int i = 1; i < length; i++) {
				shop = listOfShops.get(i);
				distance = CoordintesDistance(coordinates, new cordiantesDTO(shop.getLatitude(), shop.getLongitude()));
				if (Double.compare(distance,localdistance) < 0) {
					index = i;
					localdistance = distance;
				}
			}
			if (index != -1) {
				shop = listOfShops.get(index);
			}
		} catch (Exception e) {
		}

		return shop;
	}

	private  double CoordintesDistance(cordiantesDTO c1, cordiantesDTO c2) {

		final double distance = Math.sqrt(Math.pow((c1.getLatitude() - c2.getLatitude()), 2)
				+ Math.pow((c1.getLongitude() - c2.getLongitude()), 2));

		return distance;
	}
}