package service;

import java.util.List;

import com.reatilamanger.DTO.shopDetailsDTO;

public interface ShopResourceService {

	public void save(shopDetailsDTO shop);
	
	public List<shopDetailsDTO> getAllShops();
}
