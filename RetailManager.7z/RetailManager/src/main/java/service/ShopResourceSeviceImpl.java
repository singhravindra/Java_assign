package service;
import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import com.reatilamanger.DTO.shopDetailsDTO;
import Repository.shopResourceRepository;
import com.reatilamanger.*;

@Service
public class ShopResourceSeviceImpl implements ShopResourceService {
	
	@Inject
	private shopResourceRepository shopResourceRepository;
	
	@Override
	public void save(shopDetailsDTO shop) {
		shopResourceRepository.save(shop);
	}
	
	@Override
	public List<shopDetailsDTO> getAllShops() {
		return shopResourceRepository.getAllShops();
	}
	
}