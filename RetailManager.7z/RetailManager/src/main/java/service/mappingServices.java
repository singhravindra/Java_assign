package service;

import com.reatilamanger.DTO.cordiantesDTO;

public interface mappingServices {

	public cordiantesDTO getGeoCoordinates(String locationAddress);

}
