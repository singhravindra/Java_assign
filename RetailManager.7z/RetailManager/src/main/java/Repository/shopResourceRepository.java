package Repository;

import java.util.List;

import com.reatilamanger.*;
import com.reatilamanger.DTO.shopDetailsDTO;

public abstract class shopResourceRepository {
public abstract void save(shopDetailsDTO shop);
	
	public abstract List<shopDetailsDTO> getAllShops();



}
