package Repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.reatilamanger.*;
import com.reatilamanger.DTO.shopDetailsDTO;

@Repository
public class shopResourceRepositoryImpl extends shopResourceRepository {

	List<shopDetailsDTO> listOfShops = new ArrayList<>();

	@Override
	public void save(shopDetailsDTO shop) {
		listOfShops.add(shop);
	}

	@Override
	public List<shopDetailsDTO> getAllShops() {
		return listOfShops;
	}
}
